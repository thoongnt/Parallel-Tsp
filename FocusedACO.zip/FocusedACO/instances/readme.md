Example instances come from the sources referenced in the paper.
